/*
 * Created on 11.05.2005
 * 
 * Copyright BMSTU 2005
 */
package ru.bmstu.iu5.opsk.path;

import org.eclipse.jface.viewers.ViewerSorter;

/**
 * @author Egorova Olga
 */
public class PathTableSorter extends ViewerSorter {

	/**
	 * @param owner2
	 */
	public PathTableSorter(String param) {
		// TODO Auto-generated constructor stub
	}

	protected static final String LENGTH = "length"; //$NON-NLS-1$
	protected static final String PATH = "path"; //$NON-NLS-1$
	protected static final String COST = "cost"; //$NON-NLS-1$

}
